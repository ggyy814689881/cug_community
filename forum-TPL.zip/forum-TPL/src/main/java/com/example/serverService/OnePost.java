package com.example.serverService;

import com.example.vo.PostVo;

public interface OnePost {
	
	public PostVo selectOnePost(Long id); 
}
