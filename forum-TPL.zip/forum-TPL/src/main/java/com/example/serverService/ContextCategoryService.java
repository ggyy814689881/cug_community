package com.example.serverService;

import java.util.List;

import com.example.entity.Category;

public interface ContextCategoryService {
	public List<Category> getCategorys();
}
