package com.example;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;



@SpringBootApplication
public class ForumTplApplication {

	public static void main(String[] args) {
		SpringApplication.run(ForumTplApplication.class, args);
		System.out.println("localhost:8081");
		///res/images/avatar/0.jpg
	}

}
